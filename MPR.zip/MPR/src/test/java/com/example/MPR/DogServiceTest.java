package com.example.MPR;

import org.hibernate.service.spi.InjectService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)

public class DogServiceTest {
    private MockMvc mockMvc;
    @Mock
    private DogRepository repository;
    private AutoCloseable openMocks;
    private MyRestService myRestService;
    private MyRestService service;

    @InjectMocks
    private MyController controller;

    @BeforeEach
    public void init() {

        openMocks = MockitoAnnotations.openMocks(this);
        myRestService = new MyRestService(repository);
    }
    @BeforeEach
    public void setup(){
        this.mockMvc = MockMvcBuilders.standaloneSetup(
                new DogExceptionHandler(),controller).build();
    }
    @Test
    public void getByIdReturn200WhenDogIsPresent() throws Exception{
        Dog dog = new Dog(7,"jacek","rdzowy");
        when(service.dogRep.findById(3L)).thenReturn(Optional.of(dog));

        mockMvc.perform(MockMvcRequestBuilders.get("/dog/get/3"))
                .andExpect(jsonPath("$.wiek").value(7))
                .andExpect(jsonPath("$.imie").value("jacek"))
                .andExpect(jsonPath("$.kolor").value("rdzowy"))
                .andExpect(status().isOk());
    }
//    @Test
//    public void check400IsReturnWhenDogIsAlreadyThere() throws Exception{
//        when(service.addDog(any())).thenThrow(new DogAlreadyExistException());
//
//        mockMvc.perform(post("/dog/add")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content("{\"wiek\":3,\"imie\":\"burek\",\"kolor\":\"czarny\"}")
//                .accept(MediaType.APPLICATION_JSON))
//                .andExpect(status().isBadRequest());
//    }

    @AfterEach
    public void tearDown() throws Exception {
        openMocks.close();
    }

    @Test
    public void findFinds() {
        String name = "czarek";
        Dog dog = new Dog(9, name, "czarny");
        when(repository.findByImie(name)).thenReturn(dog);

        Dog result = myRestService.getDogByName(name);
        assertEquals(dog, result);
    }

    @Test
    public void saveSaves() {
        String name = "czarek";
        int age = 5;
        Dog dog = new Dog(age, name, "brazowy");
        ArgumentCaptor<Dog> captor = ArgumentCaptor.forClass(Dog.class);
        when(repository.save(captor.capture())).thenReturn(dog);

        myRestService.addDog(dog);
        Mockito.verify(repository, Mockito.times(1)).save(dog);
        Mockito.verify(repository, Mockito.times(1))
                .save(any());
        Dog dogFromSaveCall = captor.getValue();
        assertEquals(dog, dogFromSaveCall);
    }
    @Test
    public void dogAddThrowsExceptionWhenDogIsPresent(){
        Dog dog = new Dog(5,"reksio","fioletowy");
        dog.setId(2L);
        when(repository.findById(2L)).thenReturn(Optional.of(dog));

        assertThrows(DogAlreadyExistException.class, ()-> {
            myRestService.addDog(dog);
        });

    }
}
