package com.example.MPR;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Optional;

public class DogExceptionHandler extends ResponseEntityExceptionHandler {
    DogRepository repository;
    @ExceptionHandler(DogNotFoundException.class)
    protected ResponseEntity<Object> handlerNotFound(RuntimeException ex, WebRequest request){
        return ResponseEntity.notFound().build();
    }
    @ExceptionHandler
    public Optional<Dog> findById(long id){
        Optional<Dog> repoDog = this.repository.findById(id);
        if(repoDog.isPresent()){
            return repoDog;
        }else {
            throw new DogNotFoundException();
        }
    }

    @ExceptionHandler(ArithmeticException.class)
    protected ResponseEntity<String> handleDivideByZero(RuntimeException ex, WebRequest request){
        return ResponseEntity.badRequest().body("Sorry, no division by zero");
    }

}
