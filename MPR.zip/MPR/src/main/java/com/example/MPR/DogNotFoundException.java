package com.example.MPR;

public class DogNotFoundException extends RuntimeException{
    public DogNotFoundException(){super("Dog not found");}
}
