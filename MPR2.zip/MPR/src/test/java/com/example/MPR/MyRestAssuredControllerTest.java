package com.example.MPR;

import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.when;
import static io.restassured.RestAssured.with;
import static org.hamcrest.Matchers.equalTo;

public class MyRestAssuredControllerTest {
    private static final String URI = "http://localhost:8080";

    @Test
    public void testGet(){
        when()
                .get(URI+"/Dog/get/1")
                .then()
                .statusCode(200)
                .assertThat()
                .body("id",equalTo(1))
                .log()
                .body();
    }
    @Test
    public void testPostUser(){
        with()
                .body(new Dog(3,"czarek","rudy"))
                .contentType("application/json")
                .post(URI+"/Dog/add")
                .then()
                .statusCode(200)
                .assertThat()
                .body("wiek",equalTo(3))
                .body("imie",equalTo("czarek"))
                .body("kolor",equalTo("rudy"))
                .log()
                .body();
    }
    @Test
    public void testPut(){
        with()
                .body(new Dog(5,"lolek","brazowy"))
                .contentType("application/json")
                .put(URI+"Dog/update/lolek")
                .then()
                .statusCode(200)
                .assertThat()
                .body("imie",equalTo("lolek"))
                .body("wiek",equalTo(5))
                .body("kolor",equalTo("brazowy"))
                .log()
                .body();
    }
    @Test
    public void testDelete(){

    }
}

