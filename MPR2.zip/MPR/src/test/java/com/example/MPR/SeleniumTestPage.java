package com.example.MPR;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class SeleniumTestPage {
    WebDriver webDriver;
    @FindBy(id="imie")
    WebElement firstNameInput;

    @FindBy(id="kolor")
    WebElement kolorInput;

    @FindBy(id="wiek")
    WebElement wiekInput;

//    @FindBy(id="red")
//    WebElement redRadioButton;

    public SeleniumTestPage(WebDriver webDriver){
        this.webDriver=webDriver;
        PageFactory.initElements(webDriver,this);
    }
    public static final String URL = "https://localhost:8080/editDog";
    public void open(){
        webDriver.get(URL);
    }
    public void fillInNames(){
        firstNameInput.sendKeys("wabi sie");
        wiekInput.sendKeys("wieki");
        kolorInput.sendKeys("teczowy");
    }
//    public void selectDropdownOption(){
//        Select select = new Select(wiekInput);
//        select.selectByVisibleText("Female");
////    }
//    public void clickRedRadioButton(){
//        redRadioButton.click();
//    }
}

