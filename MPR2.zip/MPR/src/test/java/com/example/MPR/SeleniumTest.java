package com.example.MPR;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumTest {
    WebDriver driver;
    @BeforeEach
    public void setUp(){
        driver = new FirefoxDriver();
//        driver = new ChromeDriver();
//        driver = new EdgeDriver();
    }
    @Test
    public void fillInForm(){
        SeleniumTestPage page = new SeleniumTestPage(driver);
        page.open();
        page.fillInNames();


    }
}

