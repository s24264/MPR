package com.example.MPR;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {
    //    private final MyRestService myRestService;
//    @Autowired
//    public MyController(MyRestService myRestService){
//        this.myRestService=myRestService;
//    }
//    @PutMapping("/putDog")
//    public void putUser(@RequestBody Dog pies){myRestService.addDog(pies);}
//
//    @GetMapping("/getDog")
//    public List<Dog> getALLUsers(){return myRestService.getDog();}
//
//    @DeleteMapping("/poj/user/{id}")
//    public void deleteUser(@RequestParam Integer id){return myRestService.(id);}
//
//    @GetMapping("/greeting")
//    public String greeting(){
//        return "Greeting from Spring Boot!";
//    }
//
    private MyRestService service;

    public MyController(MyRestService service) {
        this.service = service;
    }

    @GetMapping("Dog/get/{id}")
    public Dog getDogByName(@PathVariable("id") int id) {
        return this.service.getDogById(id);
    }

    @PostMapping("Dog/add")
    public void addDog(@RequestBody Dog dog) {
        this.service.addDog(dog);
    }

    @PutMapping("/Dog/update/{imie}")
    public void putDog(@PathVariable String name, @RequestBody Dog updateDog) {
        service.putDog(name, updateDog);
    }

    @DeleteMapping("Dog/delete/{imie}")
    public void deleteDog(@PathVariable String name) {

        this.service.deleteDog(name);
    }
//    @GetMapping("/dog/filterByName")
//    public List<Dog> filterByName(@PathVariable String name){
//        this.service.getDogByName(name);
//        return this.service.filterByName(name);
//    }
}