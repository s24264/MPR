package com.example.MPR;

public class DogAlreadyExistException extends RuntimeException{
    public DogAlreadyExistException(){super("Dog already exist");}
}
