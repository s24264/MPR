package com.example.MPR;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Dog {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private int wiek;
    private String imie;
    private String kolor;
    Dog(int wiek,String imie,String kolor){
        this.imie=imie;
        this.wiek=wiek;
        this.kolor=kolor;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    protected Dog() {}

    public int getWiek() {
        return wiek;
    }

    public String getImie() {
        return imie;
    }

    public String getKolor() {
        return kolor;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public void setKolor(String kolor) {
        this.kolor = kolor;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }

}
