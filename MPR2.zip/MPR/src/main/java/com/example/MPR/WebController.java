package com.example.MPR;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class WebController {
    @GetMapping(value="/welcome")
    public String getWelcomeView(){return "welcome";}

    private final MyRestService service;

    @Autowired
    public WebController(MyRestService service){this.service=service;}

    @GetMapping(value="/index")
    public String getIndexView(Model model){
        model.addAttribute("dogs",service.dogRep.findAll());
        return "index";
    }

    @GetMapping(value="/addDog")
    public String getAddView(Model model){
        model.addAttribute("dog",new Dog(0,"",""));
        return "addDog";
    }
//    @PostMapping(value = "/addDog")
//    public String addDog(Dog dog, Model model, RedirectAttributes attributes){
//        if (dog.getWiek()<0){
//            model.addAttribute("errorMessage","Age cannot be less");
//            return "addDog";
//        }
//        service.addDog(dog);
//        redirectAttributes.addFlashAttribute("successMessage","Dog");
//        return "addDog";
//    }

}
